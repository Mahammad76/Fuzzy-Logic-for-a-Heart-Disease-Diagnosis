from flask import Flask, render_template, request, jsonify, redirect, url_for
import numpy as np
import skfuzzy as fuzz
import skfuzzy.membership as mf
import plotly.graph_objs as go
app = Flask(__name__)

def calculate_risk(age, bloodPressure, cholesterol, bloodSugar, hdl, ldl):
    # Variables
    x_age = np.arange(0, 101, 1)
    x_bloodPressure = np.arange(0, 221, 1)
    x_cholesterol = np.arange(100, 271, 1)
    x_bloodSugar = np.arange(0, 131, 1)
    x_hdl = np.arange(0, 81, 1)
    x_ldl = np.arange(0, 201, 1)
    y_risk = np.arange(0, 51, 1)

    # Membership functions
    age_young = mf.trapmf(x_age, [-30, -5, 30, 40])
    age_mid = mf.trapmf(x_age, [30, 40, 50, 60])
    age_old = mf.trapmf(x_age, [50, 60, 100, 100])

    bloodPressure_low = mf.trapmf(x_bloodPressure, [-30, -5, 100, 120])
    bloodPressure_mid = mf.trapmf(x_bloodPressure, [100, 120, 140, 160])
    bloodPressure_high = mf.trapmf(x_bloodPressure, [140, 160, 180, 200])
    bloodPressure_veryHigh = mf.trapmf(x_bloodPressure, [180, 200, 220, 220])

    cholesterol_low = mf.trapmf(x_cholesterol, [-30, -5, 180, 200])
    cholesterol_mid = mf.trapmf(x_cholesterol, [180, 200, 220, 240])
    cholesterol_high = mf.trapmf(x_cholesterol, [220, 240, 250, 270])

    bloodSugar_veryHigh = mf.trimf(x_bloodSugar, [90, 120, 130])

    ldl_normal= mf.trimf(x_ldl, [0, 0, 100])
    ldl_limit= mf.trimf(x_ldl, [100, 130, 160])
    ldl_high= mf.trimf(x_ldl, [130, 160, 190])
    ldl_veryHigh= mf.trapmf(x_ldl, [160, 190, 200, 200])

    hdl_low= mf.trapmf(x_hdl, [0, 0, 30, 40])
    hdl_mid= mf.trapmf(x_hdl, [30, 40, 50, 60])
    hdl_high= mf.trapmf(x_hdl, [50, 60, 80, 80])

    risk_not = mf.trapmf(y_risk, [0, 0, 5, 10])
    risk_little = mf.trapmf(y_risk, [5, 10, 15, 20])
    risk_mid = mf.trapmf(y_risk, [15, 20, 25, 30])
    risk_high = mf.trapmf(y_risk, [25, 30, 35, 40])
    risk_veryHigh = mf.trapmf(y_risk, [35, 40, 45, 50])

    # Membership degrees 
    # Calculating the membership degrees using the arguments passed to the function
    age_fit_young = fuzz.interp_membership(x_age, age_young, age)
    age_fit_mid = fuzz.interp_membership(x_age, age_mid, age)
    age_fit_old = fuzz.interp_membership(x_age, age_old, age)

    bloodPressure_fit_low = fuzz.interp_membership(x_bloodPressure, bloodPressure_low, bloodPressure)
    bloodPressure_fit_mid = fuzz.interp_membership(x_bloodPressure, bloodPressure_mid, bloodPressure)
    bloodPressure_fit_high = fuzz.interp_membership(x_bloodPressure, bloodPressure_high, bloodPressure)
    bloodPressure_fit_veryHigh = fuzz.interp_membership(x_bloodPressure, bloodPressure_veryHigh, bloodPressure)

    cholesterol_fit_low = fuzz.interp_membership(x_cholesterol, cholesterol_low, cholesterol)
    cholesterol_fit_mid = fuzz.interp_membership(x_cholesterol, cholesterol_mid, cholesterol)
    cholesterol_fit_high = fuzz.interp_membership(x_cholesterol, cholesterol_high, cholesterol)

    bloodSugar_fit_veryHigh = fuzz.interp_membership(x_bloodSugar, bloodSugar_veryHigh, bloodSugar)

    ldl_fit_normal = fuzz.interp_membership(x_ldl, ldl_normal, ldl)
    ldl_fit_limit = fuzz.interp_membership(x_ldl, ldl_limit, ldl)
    ldl_fit_high = fuzz.interp_membership(x_ldl, ldl_high, ldl)
    ldl_fit_veryHigh = fuzz.interp_membership(x_ldl, ldl_veryHigh, ldl)

    hdl_fit_low = fuzz.interp_membership(x_hdl, hdl_low, hdl)
    hdl_fit_mid = fuzz.interp_membership(x_hdl, hdl_mid, hdl)
    hdl_fit_high = fuzz.interp_membership(x_hdl, hdl_high, hdl)

    # Rules and defuzzification logic remains the same
    # Please insert your rules and defuzzification logic here
    rule1 = np.fmin(np.fmin(np.fmin(np.fmin(bloodPressure_fit_low ,cholesterol_fit_low),ldl_fit_normal), hdl_fit_high), risk_not)
    rule2 = np.fmin(np.fmin(np.fmin(np.fmin(bloodPressure_fit_low ,cholesterol_fit_low),ldl_fit_limit), hdl_fit_high), risk_little) 
    rule3 = np.fmin(np.fmin(np.fmin(np.fmin(bloodPressure_fit_low ,cholesterol_fit_low),ldl_fit_high), hdl_fit_high), risk_mid) 
    rule4 = np.fmin(np.fmin(np.fmin(np.fmin(bloodPressure_fit_low ,cholesterol_fit_low),ldl_fit_veryHigh), hdl_fit_high), risk_high) 
    rule5 = np.fmin(np.fmin(np.fmin(bloodPressure_fit_mid ,cholesterol_fit_low), hdl_fit_high), risk_not) 

    rule6 = np.fmin(np.fmin(np.fmin(age_fit_young, bloodPressure_fit_mid), cholesterol_fit_mid), risk_not) 
    rule7 = np.fmin(np.fmin(np.fmin(age_fit_mid, bloodPressure_fit_mid), cholesterol_fit_mid), risk_not) 
    rule8 = np.fmin(np.fmin(np.fmin(age_fit_old, bloodPressure_fit_mid), cholesterol_fit_mid), risk_not) 
    rule9 = np.fmin(np.fmin(np.fmin(age_fit_young, bloodPressure_fit_high), cholesterol_fit_high), risk_mid) 
    rule10 = np.fmin(np.fmin(np.fmin(age_fit_mid, bloodPressure_fit_high), cholesterol_fit_high), risk_high) 
    rule11 = np.fmin(np.fmin(np.fmin(age_fit_old, bloodPressure_fit_high), cholesterol_fit_high), risk_veryHigh) 

    rule12 = np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(age_fit_young, bloodPressure_fit_mid), cholesterol_fit_low), ldl_fit_normal), hdl_fit_low), risk_not) 
    rule13 = np.fmin(np.fmin(age_fit_young, bloodSugar_fit_veryHigh), risk_little) 
    rule14 = np.fmin(np.fmin(age_fit_mid, bloodSugar_fit_veryHigh), risk_high) 
    rule15 = np.fmin(np.fmin(age_fit_old, bloodSugar_fit_veryHigh), risk_veryHigh) 
    rule16 = np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(age_fit_young, bloodPressure_fit_low), cholesterol_fit_low), bloodSugar_fit_veryHigh), ldl_fit_normal), hdl_fit_high), risk_little) 
    rule17 = np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(age_fit_mid, bloodPressure_fit_low), cholesterol_fit_low), bloodSugar_fit_veryHigh), ldl_fit_normal), hdl_fit_high), risk_high) 
    rule18 = np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(age_fit_old, bloodPressure_fit_low), cholesterol_fit_low), bloodSugar_fit_veryHigh), ldl_fit_normal), hdl_fit_high), risk_veryHigh) 
    rule19 = np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(age_fit_mid, bloodPressure_fit_low), cholesterol_fit_low), bloodSugar_fit_veryHigh), ldl_fit_veryHigh), hdl_fit_high), risk_veryHigh) 

    rule20 = np.fmin(np.fmin(np.fmin(np.fmin(bloodPressure_fit_veryHigh, cholesterol_fit_high), ldl_fit_veryHigh), hdl_fit_high), risk_veryHigh) 
    rule21 = np.fmin(np.fmin(np.fmin(np.fmin(bloodPressure_fit_high, cholesterol_fit_high), ldl_fit_high), hdl_fit_mid), risk_veryHigh) 
    rule22 = np.fmin(np.fmin(np.fmin(np.fmin(np.fmin(age_fit_young, bloodPressure_fit_veryHigh), cholesterol_fit_high), ldl_fit_veryHigh), hdl_fit_mid), risk_mid) 
    rule23 = np.fmin(np.fmin(age_fit_mid, bloodPressure_fit_veryHigh), risk_veryHigh)  
    rule24 = np.fmin(np.fmin(age_fit_old, bloodPressure_fit_veryHigh), risk_veryHigh)

    # Placeholder for defuzzified risk level
    out_not = np.fmax(np.fmax(np.fmax(np.fmax(np.fmax(rule1,rule5),rule6),rule7),rule8),rule12)
    out_little = np.fmax(np.fmax(rule2,rule13),rule16)
    out_mid = np.fmax(np.fmax(rule3, rule9),rule22)
    out_high = np.fmax(np.fmax(np.fmax(rule4, rule10),rule14),rule17)
    out_veryHigh = np.fmax(np.fmax(np.fmax(np.fmax(np.fmax(np.fmax(np.fmax(rule11,rule15),rule18),rule19),rule20),rule21),rule23),rule24)
    out_risk = np.fmax(np.fmax(np.fmax(np.fmax(out_not, out_little), out_mid), out_high), out_veryHigh)

    defuzzified  = fuzz.defuzz(y_risk, out_risk, 'centroid')

    result = fuzz.interp_membership(y_risk, out_risk, defuzzified)
    
    return defuzzified

@app.route('/')
def home():
    return render_template('index.html')

# ... (other parts of your app.py code)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/submit_contact', methods=['POST'])
def submit_contact():
    # Here you would handle the contact form submission.
    # For simplicity, we're just returning a thank you message.
    # In a real application, you would likely send an email or store the message in a database.
    name = request.form['name']
    email = request.form['email']
    message = request.form['message']
    # Send email or save message logic goes here...
    return render_template('thank_you.html', name=name)

# ... (the rest of your app.py code)


@app.route('/diagnose', methods=['POST'])
def diagnose():
    try:
        age = int(request.form['age'])
        bloodPressure = int(request.form['bloodPressure'])
        cholesterol = int(request.form['cholesterol'])
        bloodSugar = int(request.form['bloodSugar'])
        hdl = int(request.form['hdl'])
        ldl = int(request.form['ldl'])

        # Validate inputs to ensure they are within reasonable ranges
        if not (0 <= age <= 100):
            raise ValueError("Age must be between 0 and 100.")
        if not (0 <= bloodPressure <= 220):
            raise ValueError("Blood pressure must be between 0 and 220.")
        if not (100 <= cholesterol <= 270):
            raise ValueError("Cholesterol level must be between 100 and 250.")
        if not (0 <= bloodSugar <= 150):
            raise ValueError("Blood sugar must be between 0 and 150.")
        if not (0 <= hdl <= 80):
            raise ValueError("HDL level must be between 0 and 80.")
        if not (0 <= ldl <= 200):
            raise ValueError("LDL level must be between 0 and 200.")

        risk_level = calculate_risk(age, bloodPressure, cholesterol, bloodSugar, hdl, ldl)
        

        # Generate the main graph data
        x_risk_levels = np.arange(0, 46, 1)
        y_membership_degrees = np.random.rand(len(x_risk_levels))  # Placeholder, replace with your calculation logic

        # Create the main scatter plot
        graph_data = [
            go.Scatter(x=x_risk_levels, y=y_membership_degrees, fill='tozeroy', fillcolor='rgba(0, 0, 255, 0.2)',
                       line=dict(color='blue'), name='Risk Level')
        ]

        # *NEW* Add a trace for the defuzzified value
        graph_data.append(
            go.Scatter(x=[risk_level], y=[fuzz.interp_membership(np.arange(0, 46, 1), y_membership_degrees, risk_level)],
                       mode='markers', marker=dict(size=10, color='red'), name='Centroid')
        )

        # Layout adjustments
        graph_layout = go.Layout(title='Heart Disease Risk Level', xaxis=dict(title='Risk Level'),
                                 yaxis=dict(title='Membership Degree'))
        graph_fig = go.Figure(data=graph_data, layout=graph_layout)

        # Get the HTML code for the Plotly graph
        graph_html = graph_fig.to_html(full_html=False)

        # Render the results template with the risk level and graph HTML
        return render_template('results.html', risk_level=risk_level, graph_html=graph_html)
    except Exception as e:
        # Handle exceptions by showing an error page
        return render_template('error.html', error=str(e))

if __name__ == '_main_':
    app.run(debug=True)